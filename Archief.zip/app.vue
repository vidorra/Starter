<template >
	<div class="complex-gradient font-lato">
		<NuxtPage />
	</div>
</template> 