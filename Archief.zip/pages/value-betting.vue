<template>
    <div class="min-h-screen">
        <Nav />
        <main>
            <section class="lg:px-[15%] px-[5%] text-fontcolor">
                <img class="rounded-2xl mb-10" src="assets/img/valuebetting.jpg" />

				<div class="grid grid-cols-[2fr,1fr] gap-20 px-20"> 
					<div class="auto-cols-max"> 
						<h1 class="text-4xl font-bold mb-5">Ontdek de kracht van Value Betting: Vergroot je winst met slimme sportweddenschappen!</h1>
						<p class="mb-4 text-xl">
							Leer hoe je op een winstgevende manier kunt wedden op sport. Met onze bewezen Value Betting strategie kun je waardevolle weddenschappen identificeren en positieve resultaten behalen. Ontdek de ins en outs van Value Betting, verken de voordelen en nadelen, en leer hoe je deze strategie effectief kunt toepassen in je eigen weddenschapsstrategie.
						</p>
	
						<h2 class="text-3xl font-semibold mb-4 mt-12 ">Wat is Value Betting?</h2>
						<p class="mb-4">
							Value Betting is een Engelse term voor een methode waarbij je weddenschappen plaatst waarvan de potentiële opbrengst hoger is dan de werkelijke kans op winst, zoals aangegeven door de odds. 
							Het draait om het vinden van ondergewaardeerde kansen, waarbij bookmakers de waarschijnlijkheid van een bepaalde uitkomst onderschatten. Dus met andere woorden weddenschappen waarbij jij door een analytische benadering een betere inschatting van de winkans maakt dan de bookmaker dit doet. 
							Voetbal is een populaire sport waarbij Value Betting vaak wordt gebruikt, vanwege de vele wedstrijden die wekelijks gespeeld worden en de uiteenlopende voetbal divisies in de verschillende landen. Er zijn 7 dagen per week, de hele dag door wel wedstrijden die gespeeld worden en waarop je kansen voor het toepassen van value betting kunt vinden.
						</p>


						<div class="my-4">
						<h2 class="text-3xl font-semibold my-4 mt-12 ">Voordelen van Value Betting</h2>

						<h3 class="text-2xl font-semibold my-4">Verhoogde winstgevendheid</h3>
						<p class="mb-4">
						Door waardevolle kansen te identificeren en slimme weddenschappen te plaatsen, kun je op de lange termijn winstgevend zijn met Value Betting.
						</p>

						<h3 class="text-2xl font-semibold my-4">Slimmere weddenschappen</h3>
						<p class="mb-4">
							Je kunt weddenschappen vinden waarbij bookmakers de waarschijnlijkheid van een bepaalde uitkomst onderschatten. Hierdoor kun je profiteren van ondergewaardeerde kansen en hogere winsten behalen
						</p>
						<h3 class="text-2xl font-semibold my-4">Gedisciplineerde aanpak</h3>
						<p class="mb-4">
							Met Value Betting ontwikkel je een systematische en gedisciplineerde benadering bij het selecteren van weddenschappen. Emotionele beslissingen en impulsieve inzetten worden vermeden, en je strategie is gebaseerd op data en analyse.
						</p>
						</div>		

						<h2 class="text-3xl font-semibold mb-4 mt-12 ">Nadelen van Value Betting</h2>

						<h3 class="text-2xl font-semibold my-4">Schommelingen</h3>
						<p class="mb-4">
							Begrijp dat er altijd variaties en korte termijn verliezen zijn, zelfs met een winstgevende strategie. Het is belangrijk om geduldig te blijven en te focussen op de lange termijn resultaten, in plaats van te worden beïnvloed door tijdelijke schommelingen.
						</p>

						<h3 class="text-2xl font-semibold my-4">Tijdsinvestering</h3>
						<p class="mb-4">
							Realiseer je dat het vinden van waardevolle weddenschappen grondig onderzoek en analyse vereist. Het vergt tijd en toewijding om statistieken, trends en andere relevante informatie te analyseren.
						</p>

						<img class="rounded-lg mb-4" src="assets/img/football.jpg" />

						<h2 class="text-3xl font-semibold mb-4 mt-12 ">Toepassen van Value Betting toe in je strategie </h2>

						<h3 class="text-2xl font-semibold my-4">Statistieken analyseren </h3>
						<p class="mb-4">
							Leer hoe je gedetailleerde statistieken en andere relevante informatie kunt analyseren om trends, sterke en zwakke punten van teams en spelers te identificeren. Dit helpt je bij het maken van weloverwogen beslissingen bij het selecteren van weddenschappen.
						</p>

						<h3 class="text-2xl font-semibold my-4">Vergelijk odds</h3>
						<p class="mb-4">
							Ontdek hoe je de odds van verschillende bookmakers kunt vergelijken om waardevolle kansen te vinden waarbij de impliciete waarschijnlijkheid lager is dan jouw inschatting van de werkelijke waarschijnlijkheid. Door te wedden op wedstrijden waar de odds niet de werkelijke waarschijnlijkheid weerspiegelen, kun je waarde vinden en winst behalen.
						</p>

						<h3 class="text-2xl font-semibold my-4">Beheer je bankroll</h3>
						<p class="mb-4">
							Leer hoe je verstandig bankrollmanagement kunt implementeren om risico's te beperken en je kapitaal effectief te beheren. Bepaal een passende inzetgrootte op basis van de waarde van de weddenschap en zorg voor een gedisciplineerde aanpak bij het beheren van je geld.
						</p>

						<h2 class="text-3xl font-semibold mb-4 mt-12 ">Toepassen van Value Betting toe in je strategie </h2>

						<h3 class="text-2xl font-semibold my-4">Ontdek meer over Value Betting </h3>
						<p class="mb-4">
							Wil je meer weten over Value Betting en hoe je deze winstgevende strategie kunt toepassen in je eigen sportweddenschappen? Lees onze blog "De Code Gekraakt: Hoe Ik Winstgevend Werd met de Value Betting Strategie" voor diepgaande inzichten, praktische tips en concrete voorbeelden die je kunnen helpen bij het implementeren van Value Betting in je strategie.
						</p>
							<p class="my-4">
						Begin vandaag nog met het vergroten van je kansen op succesvolle sportweddenschappen door de kracht van Value Betting te benutten!
						</p>

					</div>
					<!-- Aside -->
					 
					<div class="auto-cols-min	">
						<h2 class="text-2xl font-semibold mb-4">Latest Blogs</h2>

						<ul class="grid grid-cols-1 gap-5 mb-8 mt-2 ">
							<template v-for="(blog, i) in flatBlogs.slice(0, 3)">
								<li class="list-item bg-white rounded-xl text-default text-fontcolor font-semibold hover:text-primary-900 underline underline-offset-4 decoration-wavy decoration-primary/40 hover:decoration-primary transition-all">
									<div class="px-7 py-5 rounded-lg">
										<NuxtLink :to="`${blog._path}`">
											<img :src="getImageSrc(i)" @error="useDefaultImage" class="mb-4 rounded-md mt-2" alt="Blog Image" />
											<span class="text-xl">{{ blog.title }}</span> 
										</NuxtLink>   
									</div>
								</li> 
							</template>
						</ul>
					</div> 	
				</div>	
			</section>
		</main>
	</div> 
</template>

<script setup>
import { computed } from 'vue';
import { onMounted } from 'vue';

let serviceNav = ref(null);

const getImageSrc = (i) => `/assets/img/Blog-${i + 1}.jpg`;

const useDefaultImage = (e) => {
    e.target.src = '/assets/img/default-image-1.jpg';
  }
 


onMounted(async () => {
  serviceNav.value = await useAsyncData("navigation", async () => {
    const navData = await fetchContentNavigation(queryContent("blogs"));
    return navData;
  });
  console.log("serviceNav :", serviceNav.value);
  console.log(JSON.stringify(serviceNav.value, null, 2));
});



const flatBlogs = computed(() => {
  if (serviceNav.value && serviceNav.value.data[0]) {
    return serviceNav.value.data[0].children.flatMap(b => b.children);
  }
  return []; // fallback to an empty array if serviceNav[0] is not defined
});
useHead({
  title: "Blogs",
});
</script>